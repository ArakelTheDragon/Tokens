#!/bin/bash
sudo apt install python3
gnome-terminal -- bash -c "python3 start_miner_linux.py; exec bash"

