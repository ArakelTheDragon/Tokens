import json
import subprocess

def update_config_file(worker_id):
    # Directly reference the config.json file
    config_file_path = 'config.json'
    
    # Load the existing configuration
    try:
        with open(config_file_path, 'r') as file:
            config = json.load(file)
    except FileNotFoundError:
        config = {}

    # Update the worker ID
    config["pools"][0]["worker-id"] = worker_id

    # Write the updated configuration back to the file
    with open(config_file_path, 'w') as file:
        json.dump(config, file, indent=4)
    print(f"Updated config.json with worker-id: {worker_id}")

def start_webchain_miner():
    try:
        # Start the webchain-miner, assuming it's in the same directory
        subprocess.run(["sudo", "./webchain-miner"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Failed to start webchain-miner: {e}")

def main():
    # Prompt for address
    address = input("Enter the address followed by 'WorkTH' or 'WorkTHR': ")
    
    # Validate input
    if not (address.endswith("WorkTH") or address.endswith("WorkTHR")):
        print("Invalid input. Please ensure the address ends with 'WorkTH' or 'WorkTHR'.")
        return
    
    # Update the config file and start the miner
    update_config_file(address)
    start_webchain_miner()

if __name__ == "__main__":
    main()

