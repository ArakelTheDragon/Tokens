#!/bin/bash
sudo apt install python3
gnome-terminal -- bash -c "python3 /path/to/your/start_miner.py; exec bash"

